#include "nmplv.h"


nm64s *L0;
nm64s *L1;
nm64s *G0;
nm64s *G1;
const int KB=1024/8;
const int SizeL0=128*KB;
const int SizeL1=128*KB;

const int SizeG0=128*KB;
const int SizeG1=128*KB;



//////////////////////////////////////////////
int main()
{
	
 
	unsigned int crc = 0;

	nmppsMalloc_ (&L0, SizeL0, MEM_LOCAL);
	nmppsMalloc_ (&L1, SizeL1, MEM_LOCAL);
	nmppsMalloc_ (&G0, SizeG0, MEM_GLOBAL);
	nmppsMalloc_ (&G1, SizeG1, MEM_GLOBAL);

	int	MaxLongSize=2*1024;
	MaxLongSize=MIN(MaxLongSize,SizeL0);
	MaxLongSize=MIN(MaxLongSize,SizeG0);

	
	nmppsRand_64s((nm64s*)L0,SizeL0);
	nmppsRand_64s((nm64s*)L1,SizeL1);

	nm64s c=0xAAAAAAAACCCCCCCCL;
	nmppsSet_64s((nm64s*)G0,&c,(SizeG0));
 


	for(int LongSize=1;LongSize<=MaxLongSize;LongSize++)
	{
		nmppsAddV_64s((nm64sc*)L0,(nm64sc*)L1,(nm64sc*)G0,LongSize);	
		nmppsCrc_32u((nm32u*)G0,MIN(LongSize*4+128,SizeG0*4),&crc);
	}
	//! \fn void nmppsAddV_64s(nm64sc*,nm64sc*,nm64sc*,int)

	nmppsFree(L0);
	nmppsFree(L1);
	nmppsFree(G0);
	nmppsFree(G1);

	


	return crc>>2;


}