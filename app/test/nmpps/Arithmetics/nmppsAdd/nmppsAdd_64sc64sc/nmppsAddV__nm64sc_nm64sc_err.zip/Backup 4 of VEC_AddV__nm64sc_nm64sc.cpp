#include "nmplv.h"


nm64s *L0;
nm64s *L1;
nm64s *G0;
nm64s *G1;
const int KB=1024/8;
const int SizeL0=60*KB;
const int SizeL1=120*KB;

const int SizeG0=60*KB;
const int SizeG1=120*KB;



//////////////////////////////////////////////
int main()
{
	
 
	unsigned int crc = 0;

	nmppsMalloc_ (&L0, SizeL0, 0);
	nmppsMalloc_ (&L1, SizeL1, 1);
	nmppsMalloc_ (&G0, SizeG0, 2);
	nmppsMalloc_ (&G1, SizeG1, 3);
	if ((L0==0)||(L1==0)||(G0==0)||(G1==0)) return -1;

	int	MaxLongSize=2*1024;
	MaxLongSize=MIN(MaxLongSize,SizeL0);
	MaxLongSize=MIN(MaxLongSize,SizeG0);

	
	nmppsRand_64s((nm64s*)L0,SizeL0);
	nmppsRand_64s((nm64s*)L1,SizeL1);

	nm64s c=0xAAAAAAAACCCCCCCCL;
	nmppsSet_64s((nm64s*)G0,&c,(SizeG0));
 


	for(int LongSize=1;LongSize<=MaxLongSize;LongSize++)
	{
		nmppsAddV_64s((nm64sc*)L0,(nm64sc*)L1,(nm64sc*)G0,LongSize);	
		nmppsCrc_32u((nm32u*)G0,MIN(LongSize*4+128,SizeG0*4),crc);
	}
	//! \fn void nmppsAddV_64s(nm64sc*,nm64sc*,nm64sc*,int)

	nmppsFree_(L0);
	nmppsFree_(L1);
	nmppsFree_(G0);
	nmppsFree_(G1);

	


	return crc>>2;


}