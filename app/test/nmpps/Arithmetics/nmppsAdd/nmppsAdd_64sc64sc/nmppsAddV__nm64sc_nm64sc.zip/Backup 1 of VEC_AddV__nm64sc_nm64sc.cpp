#include "nmplv.h"


nm64s *L0;
nm64s *L1;
nm64s *G0;
nm64s *G1;
const int KB=1024/8;
const int SizeL0=128*KB;
const int SizeL1=128*KB;

const int SizeG0=128*KB;
const int SizeG1=128*KB;



//////////////////////////////////////////////
int main()
{
	
 
	unsigned int crc = 0;

	VEC_Malloc (&L0, SizeL0, MEM_LOCAL);
	VEC_Malloc (&L1, SizeL1, MEM_LOCAL);
	VEC_Malloc (&G0, SizeG0, MEM_GLOBAL);
	VEC_Malloc (&G1, SizeG1, MEM_GLOBAL);

	int	MaxLongSize=2*1024;
	MaxLongSize=MIN(MaxLongSize,SizeL0);
	MaxLongSize=MIN(MaxLongSize,SizeG0);

	
	VEC_Rand((nm64s*)L0,SizeL0);
	VEC_Rand((nm64s*)L1,SizeL1);

	nm64s c=0xAAAAAAAACCCCCCCCL;
	VEC_Fill((nm64s*)G0,&c,(SizeG0));
 


	for(int LongSize=1;LongSize<=MaxLongSize;LongSize++)
	{
		VEC_AddV((nm64sc*)L0,(nm64sc*)L1,(nm64sc*)G0,LongSize);	
		VEC_Crc((nm32u*)G0,MIN(LongSize*4+128,SizeG0*4),crc);
	}
	//! \fn void VEC_AddV(nm64sc*,nm64sc*,nm64sc*,int)

	VEC_Free(L0);
	VEC_Free(L1);
	VEC_Free(G0);
	VEC_Free(G1);

	


	return crc>>2;


}